%include "printf64.asm"

section .data
    key:  db 0x12, 0xf1, 0x20, 0xe1, 0x65, 0x11
          db 0x40, 0x31, 0x71, 0x20, 0x65, 0x60,
          db 0x91, 0x10, 0x31, 0x40, 0xa5, 0x65,
          db 0x51, 0x91, 0xb1, 0x31, 0x50, 0x65,
          db 0x11, 0x40, 0x31, 0x71, 0x20, 0x65,
          db 0x40, 0x31, 0x50, 0x60, 0x91, 0x81,
          db 0x50, 0x71, 0x41, 0xf1, 0xa1, 0xf1,
          db 0x20, 0xf0, 0x85, 0x67

key_len equ 46

section .text
extern printf
global main

main:
    push rbp
    mov rbp, rsp

    mov rcx, 0              ; Contor pentru loop

decrypt_loop:
    cmp rcx, key_len        ; Verificăm dacă am terminat toate caracterele 
    je print_result

    mov al, [key + rcx]     ; Luăm byte-ul curent
    xor al, 0x67            ; Pasul 1: XOR cu 0x67 

    ; Pasul 2: Interschimbarea biților (nibble swap) [cite: 39, 45]
    mov dl, al
    shl al, 4               ; Mută biții 0-3 în poziția 4-7
    shr dl, 4               ; Mută biții 4-7 în poziția 0-3
    or al, dl               ; Combină cele două părți

    mov [key + rcx], al     ; Salvăm byte-ul modificat înapoi
    inc rcx
    jmp decrypt_loop

print_result:
    PRINTF64 `%s\n\x0`, key ; Afișăm mesajul final [cite: 40]

    xor rax, rax
    leave
    ret