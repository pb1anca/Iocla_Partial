%include "printf64.asm"

section .data
    literals: db 0x49, 0x74, 0x27, 0x73, 0x20,
              db 0x74, 0x69, 0x6d, 0x65, 0x20,
              db 0x74, 0x6f, 0x20, 0x65, 0x78,
              db 0x69, 0x74, 0x20, 0x74, 0x68,
              db 0x65, 0x20, 0x4d, 0x61, 0x74,
              db 0x63, 0x61, 0x76, 0x65, 0x3f, 0x00

    str: dq literals

; DO NOT MODIFY THE CODE FROM HERE BELOW
str_len equ 30

section .text
extern printf
global main

main:
    push rbp
    mov rbp, rsp

    mov rax, qword [str]
    mov byte [rax + str_len - 1], '!'
    mov byte [rax + str_len - 8], 'B'

    mov rax, qword [str]
    PRINTF64 `%s\n\x0`, rax

    xor rax, rax
    leave
    ret
