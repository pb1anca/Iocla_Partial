#include <stdio.h>
#include <stdint.h>

void *get_ptr(void);

int main () {
    typedef char* (*func_ptr_t)(uint64_t, char *);
    void *ptr = get_ptr();
    func_ptr_t my_func = (func_ptr_t)ptr;
    char *result = my_func(0xdeadcafebabeb00b, "just a simple cast");
    
    printf("%s\n", result);
    
    return 0;
}