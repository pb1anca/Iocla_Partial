#include <stdio.h>

void *get_ptr(void);

int main() {
    void **ptr = (void **)get_ptr();
    while (ptr != NULL) {
        if (*(char **)ptr != NULL) {
            printf("%s\n", (char *)*ptr);
        }
        ptr = (void **)*ptr;
    }
    
    return 0;
}