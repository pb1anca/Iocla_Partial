#include <stdio.h>
#include <string.h>

void have_same_students(void *some_students, size_t size);

struct student_t {
    char uuid[16];
    char is_enrolled;
    int age;
} students[3] = {
    {.is_enrolled = 1, .age = 20},
    {.is_enrolled = 1, .age = 21},
    {.is_enrolled = 1, .age = 22}
};

void print_parity()
{
    for (int i = 0; i < 3; i++) {
        size_t byte_offset = (char*)&students[i].age - (char*)students;
        size_t bit_position = byte_offset * 8; // LSB position
        printf("%lu%s", bit_position + 7, (i < 2) ? ", " : "\n");
    }
}

void assign_uuid()
{
    for (int i = 0; i < 3; i++) {
        memset(students[i].uuid, 0, 16);
        students[i].uuid[15] = (char)i;
    }
}

int main(void)
{
    print_parity();
    assign_uuid();
    have_same_students(students, sizeof(students));

    return 0;
}