%include "printf64.asm"

struc hero
    codename: resb 32
    next: resq 1
endstruc

section .data
    batman:
        istruc hero
            at codename, db 0x42, 0x61, 0x74, 0x73, 0
            at next, dq robin
        iend
    superman:
        istruc hero
            at codename, db 0x53, 0x74, 0x65, 0x65, 0x6c, 0x6d, 0x61, 0x6e, 0
            at next, dq 0
        iend
    flash:
        istruc hero
            at codename, db 0x53, 0x70, 0x65, 0x65, 0x64, 0x79, 0
            at next, dq arrow
        iend
    arrow:
        istruc hero
            at codename, db 0x51, 0x75, 0x65, 0x65, 0x6e, 0
            at next, dq superman
        iend
    robin:
        istruc hero
            at codename, db 0x52, 0x65, 0x64, 0x42, 0x6f, 0x79, 0
            at next, dq flash
        iend

section .text
extern printf
global main

main:
    push rbp
    mov rbp, rsp

    mov rax, batman
    ; TODO:  Go through the linked list and print every hero's codename starting with batman
    
    xor rax, rax
    leave
    ret
