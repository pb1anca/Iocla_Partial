#include <stdio.h>

void *get_ptr(void);

int main() {
    void *ptr = get_ptr();
    (void)ptr;
    // TODO: dereference the pointer until you get an address to an actual string
    return 0;
}
