#include <stdio.h>
#include <stdint.h>

void *get_ptr(void);

int main (){
    void *ptr = get_ptr();
    (void)ptr;
    // TODO: find a way to call the function located at this address
    return 0;
}
