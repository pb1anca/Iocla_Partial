%include "printf64.asm"

section .bss
    struc person
        p_uuid:    resq 1
        p_name:    resb 16
    endstruc

section .data
    complicated dw 0x12, 0x56, 0x1000, 0xbabe

    linear db 0x78, 0x56, 0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0x4d, 0x61, 0x72, \
    0x69, 0x61, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
    0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x22, 0x41, 0x6e, 0x64, 0x72, 0x65, \
    0x69, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x11, 0x11, \
    0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x43, 0x72, 0x69, 0x73, 0x74, 0x69, 0x6e, \
    0x61, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00

section .text
extern printf
global main

main:
    push rbp
    mov rbp, rsp

    xor rax, rax
    mov ax, [complicated]     
    
    mov rbx, 1             
loop_max:
    mov cx, [complicated + rbx*2]
    sub cx, ax    
    js skip_update           
    add ax, cx                
skip_update:
    inc rbx
    cmp rbx, 4
    jl loop_max

    PRINTF64 "a) 0x%hx", rax   
    PRINTF64 "%c", 10         

    xor rax, rax
    xor rbx, rbx
sum_loop:
    movzx rcx, word [complicated + rbx*2]
    add rax, rcx              
    inc rbx
    cmp rbx, 4
    jl sum_loop

    popcnt rax, rax      
    test rax, 1              
    jz even_bits
    PRINTF64 "b) Odd number of set bits"
    jmp end_b
even_bits:
    PRINTF64 "b) Even number of set bits" ;
end_b:
    PRINTF64 "%c", 10
    PRINTF64 "c)%c", 10
    xor rbx, rbx 
print_persons:
    imul rcx, rbx, 24
    lea rsi, [linear + rcx]
    
    PRINTF64 "Person %d:%c", rbx, 10
    

    mov rdx, [rsi]
    PRINTF64 "	UUID: 0x%lx%c", rdx, 10

    lea rdx, [rsi + 8]
    PRINTF64 "	Name: %s%c", rdx, 10

    inc rbx
    cmp rbx, 3
    jl print_persons

    xor rax, rax
    leave
    ret